<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\PaymentHistory;

class AdminController extends Controller
{
    public function index(){

        $payment_history = PaymentHistory::all();
        return view('admin.index', [
            'title' => 'Edit Profile',
            'active' =>'user',
            'payment' => $payment_history,
        ]);
    }
}
<?php

namespace App\Models;

use App\Models\PaymentMethodHeader;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class PaymentMethod extends Model
{
    use HasFactory;
    protected $guarded = ['id'];
    public function method_header(){
        return $this->belongsTo(PaymentMethodHeader::class);
    }

    public function payment_history(){
        return $this->hasMany(PaymentHistory::class);
    }
}
<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\AccountController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\DashboardController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get('/dashboard', [DashboardController::class, 'index'])->name('home')->middleware('auth');

Route::get('/login', [LoginController::class, 'index'])->name('login')->middleware('guest');
Route::post('/login', [LoginController::class, 'verifikasi'])->middleware('guest');

Route::get('/register', [RegisterController::class, 'index'])->name('register')->middleware('guest');
Route::post('/register', [RegisterController::class, 'verify'])->middleware('guest');

Route::get('/logout', [LoginController::class, 'logout']);

Route::get('/product', [ProductController::class, 'index'])->name('product')->middleware('auth');
Route::get('/delcart/{userId}', [OrderController::class, 'deleteCart'])->middleware('auth');
Route::post('/deleteproduct', [OrderController::class, 'delete'])->middleware('auth');

Route::post('/order/{id}', [OrderController::class, 'index'])->middleware('auth');

Route::post('/checkout', [OrderController::class, 'checkout'])->middleware('auth');
Route::get('/checkout', [OrderController::class, 'index_checkout'])->middleware('auth');
Route::get('/checkout/method', [OrderController::class, 'method_id'])->middleware('auth');
Route::get('/checkout/method_id', [OrderController::class, 'getfees'])->middleware('auth');

Route::get('/cart', [OrderController::class, 'cart'])->middleware('auth');
Route::get('/invoice/{id}', [OrderController::class, 'invoice'])->middleware('auth');
Route::get('/user/transaction', [UserController::class, 'index'])->middleware('auth');

Route::get('/account', [AccountController::class, 'index'])->middleware('auth');
Route::get('/account/edit', [AccountController::class, 'editprofile'])->middleware('auth');
Route::post('/account/edit', [AccountController::class, 'edit'])->middleware('auth');

Route::get('/account/change_password', [AccountController::class, 'cpass'])->middleware('auth');
Route::post('/account/change_password', [AccountController::class, 'chpass'])->middleware('auth');

Route::post('/editorder/{id}', [OrderController::class, 'editCart'])->middleware('auth');


Route::get('/admin/dashboard', [AdminController::class, 'index'])->middleware('admin');

<?php $__env->startSection('content'); ?>
<section>
    <div class="container-fluid">
        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title d-flex align-items-center flex-wrap mb-30">
                        <h2 class="mr-40"><?php echo e($title); ?> Page</h2>

                    </div>
                </div>
                <!-- end col -->
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper mb-30">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="#0">Dashboard</a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">
                                    <?php echo e($title); ?>

                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
        </div>
        <!-- ========== title-wrapper end ========== -->

        <!-- Invoice Wrapper Start -->
        <div class="invoice-wrapper">
            <div class="row">
                <div class="col-12">
                    <div class="invoice-card card-style mb-30 p-5">
                        <div class="invoice-header align-items-center">
                            <div class="invoice-for">
                                <h2 class="mb-10">Invoice <span class="text-primary fw-bold">
                                        #<?php echo e($order->invoice_id); ?></span></h2>
                                <p class="fw-bold h4">
                                    Status : <?php echo e($order->status_order->status_name); ?>

                                </p>
                            </div>
                            <div class="invoice-logo">
                                <img src="<?php echo e(url('')); ?>/assets/images/invoice/uideck-logo.svg" alt="" />
                            </div>
                            <div class="invoice-date">
                                <p><span>Date Issued:</span> 20/02/2024</p>
                                <p><span>Date Due:</span> 20/02/2028</p>
                            </div>
                        </div>
                        <div class="invoice-address ">
                            <div class="address-item">
                                <h5 class="text-bold">Invoiced To</h5>
                                <h1><?php echo e(Auth::user()->name); ?></h1>
                                <p class="text-sm">
                                    <span class="text-medium">Handphone:</span>
                                    <?php echo e(Auth::user()->no_hp); ?>

                                </p>
                                <p class="text-sm">
                                    <span class="text-medium">Email:</span>
                                    <?php echo e(Auth::user()->email); ?>

                                </p>
                            </div>
                            <div class="address-item">
                                <h5 class="text-bold">Pay To</h5>
                                <h1>Blue Canteen</h1>
                                <p class="text-sm">
                                    Universitas Kristen Satya Wacana
                                </p>
                                <p class="text-sm">
                                    <span class="text-medium">Email:</span>
                                    admin@bluecanteen.com
                                </p>
                            </div>
                        </div>
                        <h4 class="fw-bold mb-10">Invoice Payment</h4>
                        <div class="table-responsive mb-30">
                            <table class="invoice-table table">
                                <thead>
                                    <tr>
                                        <th class="service ">
                                            <h6 class="text-sm text-medium">Method</h6>
                                        </th>
                                        <th class="desc ">
                                            <h6 class="text-sm text-medium">Payment From</h6>
                                        </th>
                                        <th class="qty ">
                                            <h6 class="text-sm text-medium">Payment to</h6>
                                        </th>
                                        <th class="amount text-end">
                                            <h6 class="text-sm text-medium">Price</h6>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <p class="text-sm"><?php echo e($payment->payment_method->name); ?></p>
                                        </td>
                                        <td>
                                            <p class="text-sm ">
                                                <strong><?php echo e($payment->holder_number); ?></strong><br>
                                                <?php echo e($payment->holder_name); ?>

                                            </p>
                                        </td>
                                        <td>
                                            <p class="text-sm ">
                                                <strong><?php echo e($payment->payment_method->holder_number); ?></strong><br>
                                                <?php echo e($payment->payment_method->holder_name); ?>

                                            </p>
                                        </td>
                                        <td>
                                            <p class="text-sm text-end">Rp.
                                                <?php echo e(number_format($payment->total_harga,2,',','.')); ?></p>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <h4 class="fw-bold mb-10">Invoice Items</h4>
                        <div class="table-responsive">
                            <table class="invoice-table table">
                                <thead>
                                    <tr>
                                        <th class="service fw_bo">
                                            <h6 class="text-sm text-medium ">Products</h6>
                                        </th>
                                        <th class="desc text-center">
                                            <h6 class="text-sm text-medium">Quantity</h6>
                                        </th>
                                        <th class="qty text-center">
                                            <h6 class="text-sm text-medium">Description</h6>
                                        </th>
                                        <th class="amount text-end">
                                            <h6 class="text-sm text-medium">Price</h6>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $od): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <p class="text-sm"><?php echo e($od->product->name); ?></p>
                                        </td>
                                        <td>
                                            <p class="text-sm text-center">
                                                <?php echo e($od->quantity); ?>

                                            </p>
                                        </td>
                                        <td>
                                            <p class="text-sm text-center"><?php echo e($od->description); ?></p>
                                        </td>
                                        <td>
                                            <p class="text-sm text-end">Rp.
                                                <?php echo e(number_format($od->total_harga,2,',','.')); ?></p>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td colspan="3">
                                            <p class="text-sm fw-bold">Subtotal Product</p>
                                        </td>

                                        <td>
                                            <p class="text-sm text-end fw-bold">Rp.
                                                <?php echo e(number_format($od->total_harga,2,',','.')); ?></p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="3">
                                            <p class="text-sm fw-bold">Transaction Fee</p>
                                        </td>

                                        <td>
                                            <p class="text-sm text-end fw-bold">Rp.
                                                <?php echo e(number_format($payment_method->fee,2,',','.')); ?></p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="3">
                                            <p class="text-sm fw-bold">Total Price</p>
                                        </td>

                                        <td>
                                            <p class="text-sm text-end fw-bold">Rp.
                                                <?php echo e(number_format($payment->total_harga,2,',','.')); ?></p>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="note-wrapper warning-alert py-4 px-sm-3 px-lg-5">
                            <div class="alert">
                                <h5 class="text-bold mb-15">Notes:</h5>
                                <p class="text-sm text-gray">
                                    Harap transfer sesuai dengan nominal yang tertera. Pastikan data yang anda masukkan
                                    benar. Jika ada pertanyaan bisa langsung hubungi Admin
                                </p>
                            </div>
                        </div>
                        <div class="invoice-action">
                            <ul class="
                        d-flex
                        flex-wrap
                        align-items-center
                        justify-content-center
                      ">
                                <li class="m-2">
                                    <a href="#0" class="main-btn primary-btn-outline btn-hover">
                                        Download Invoice
                                    </a>
                                </li>
                                <li class="m-2">
                                    <a href="#0" class="main-btn primary-btn btn-hover">
                                        Send Invoice
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>
                <!-- ENd Col -->
            </div>
            <!-- End Row -->
        </div>
        <!-- Invoice Wrapper End -->
    </div>
    <!-- end container -->
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH A:\appLaravel\tugas_akhir\resources\views/invoice_detail.blade.php ENDPATH**/ ?>